import java.util.*;
class HashMapDemo{
	
	public static void main(String args[]) {
		
		HashMap<String,Double> hm= new HashMap<String,Double>();
		hm.put("John Doe", new Double(3434.34));
		hm.put("Tom Smith", new Double(123.22));
		hm.put("Jane Baker", new Double(1378.00));
		hm.put("TodHall", new Double(99.22));
		hm.put("Ralph Smith", new Double(-19.08));
		
		Set<Map.Entry<String,Double>> set= hm.entrySet(); // Get a set of the entries
		System.out.println(set.getClass().getName());
		Iterator<Map.Entry<String,Double>> i= set.iterator(); // Get an iterator
		while(i.hasNext()) { // Display elements
			Map.Entry<String,Double> me = (Map.Entry<String,Double>)i.next();
			System.out.println(me.getKey() + ": "+ me.getValue());
		}
		// Deposit 1000 into John Doe's account
		double balance = ((Double)hm.get("John Doe")).doubleValue();
		hm.put("John Doe", new Double(balance + 1000));
		if(hm.containsKey("John Doe")){
			hm.replace("John Doe", hm.get("John Doe"), 1000+hm.get("John Doe")); 
		}
		System.out.println("John Doe's new balance: " + hm.get("John Doe")); 
	} 
}
