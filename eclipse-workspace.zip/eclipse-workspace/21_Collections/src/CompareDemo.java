import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class CompareDemo implements Comparator<Student>{

	public static void main(String[] args) {
		ArrayList<Student> a = new ArrayList<>();
		a.add(new Student(101, "rahul"));
		a.add(new Student(104, "harshit"));
		a.add(new Student(103, "mudit"));
		
		Collections.sort(a, new CompareDemo());
		System.out.println(a);

	}

	@Override
	public int compare(Student o1, Student o2) {
		return o1.name.compareTo(o2.name);
	}

}
