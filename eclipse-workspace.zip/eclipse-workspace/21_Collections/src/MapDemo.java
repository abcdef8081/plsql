import java.util.*;

public class MapDemo {

	public static void main(String[] args) {
		
		HashMap hm = new HashMap();
		hm.put(101, 1000);
		hm.put(102, "rahul");
		hm.put("name", "rahul");
		hm.put(103, 105.5678);
		System.out.println(hm);
		
		Map lhm = new LinkedHashMap();
		lhm.put(101, 1000);
		lhm.put(102, "rahul");
		lhm.put("name", "rahul");
		lhm.put(103, 105.5678);
		System.out.println(lhm);
		
		Map tm = new TreeMap();
		tm.put(101, 1000);
		tm.put(102, "rahul");
		tm.put(103, 105.5678);
		System.out.println(tm);
		
	}

}
