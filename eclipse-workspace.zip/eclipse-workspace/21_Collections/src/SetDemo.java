import java.util.*;

public class SetDemo {

	public static void main(String[] args) {
		Set s = new HashSet();
		s.add(10);
		s.add("rahul");
		s.add(12.5f);
		s.add(10);
		System.out.println("HashSet " + s.toString());
		
		Set l = new LinkedHashSet();
		l.add(10);
		l.add("rahul");
		l.add(12.5f);
		l.add(10);
		System.out.println("LinkedHashSet" + l.toString());
		
		Set t = new TreeSet();
		t.add(10);
		t.add(15);
		t.add(8);
		System.out.println("TreeSet " + t.toString());
		Iterator itr = t.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
	}

}
