import java.util.*;

public class ListDemo {

	public static void main(String[] args) {
		List l = new ArrayList();
		l.add(10);
		l.add("rahul");
		l.add(12.5f);
		l.add(10);
		l.add(2, 9);
		l.remove(2);
		System.out.println("ArrayList " + l.toString());
		
		List ll = new LinkedList();
		ll.add(10);
		ll.add("rahul");
		ll.add(12.5f);
		ll.add(10);
		System.out.println("LinkedList " + ll.toString());

	}

}
