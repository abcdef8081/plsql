
public class Student //implements Comparable<Student> 
{

	int sid;
	String name;
	
	Student(int sid, String name){
		this.sid = sid;
		this.name = name;
	}
	
	@Override
	public String toString() {
		return "Student [sid=" + sid + ", name=" + name + "]";
	}

	/*@Override
	public int compareTo(Student s) {
		return this.sid - s.sid;
	}*/
}
