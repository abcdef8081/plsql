
public class Ex1 {

	public static void main(String[] args) {
		int n = 124;
		Ex1 e1 = new Ex1();
		System.out.println(e1.cubes(n));

	}
	public int cubes(int n) {
		int a = n;
		int sum = 0;
		while(a > 0) {
			int r = a%10;
			sum += r*r*r;
			a = a/10;
		}
		return sum;
	}

}
