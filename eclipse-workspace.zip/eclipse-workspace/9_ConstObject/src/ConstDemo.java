
public class ConstDemo {
	
	ConstDemo(){
		System.out.println("Default Constructor");
	}
	
	ConstDemo(String s){
		System.out.println("Param Constructor " + s);
	}
	
	public static void main(String[] args) {
	ConstDemo c1 = new ConstDemo();
	ConstDemo c2 = new ConstDemo("by user");
	//System.out.println(c1);
	}
}
