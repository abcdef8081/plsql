
public class ObjectDemo {

	public static void main(String[] args) {
		ObjectDemo o1;
		//o1 = null;
		o1 = new ObjectDemo();
		ObjectDemo o2 = new ObjectDemo();
		System.out.println(o1);
		System.out.println(o2);
		//System.out.println(o1.hashCode());
		o1 = o2;
		System.out.println(o1);
		System.out.println(o2);

	}

}
