package com;

public class B extends A{
	String b = "B Class";
	
	B(){
		System.out.println("Default B");
	}
	
	public void showB() {
		System.out.println("I am show of b");
	}

}
