package com;

public class A {
	int a=100;
	
	A(){
		System.out.println("Default A");
	}
	A(String msg){
		System.out.println("Param A" + msg);
	}
	
	public void showA(){
		System.out.println("I am show of a");
	}
	
	public static void testA() {
		System.out.println("Static method A");
	}
}
