package com;

public class C extends B {
	int c=300;
	
	C(){
		System.out.println("Default C");
	}
	
	C(String string) {
		System.out.println("Param C " + string);
	}

	public void showC() {
		System.out.println("I am show of c");
	}

	public static void main(String[] args) {
		C obj_C = new C();
		obj_C.showA();
		obj_C.showB();
		obj_C.showC();
		
		C obj_C2 = new C("Hello C");
		
		System.out.println(obj_C.a);
		System.out.println(obj_C.b);
		System.out.println(obj_C.c);
		
		testA();
	}

}
