
public class MethodDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MethodDemo md = new MethodDemo();
		md.greet();
	}
	
	public void greet() {
		System.out.println("This is my greet function");
	}

}
