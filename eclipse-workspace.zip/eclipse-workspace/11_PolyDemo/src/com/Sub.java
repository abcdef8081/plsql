package com;

public class Sub extends Base {
	int c=300;
	
	Sub(){
		System.out.println("Default C");
	}
	
	Sub(String string) {
		System.out.println("Param C " + string);
	}

	public void showC() {
		System.out.println("I am show of c");
	}	
	public void showB() {
		System.out.println("Override of b in c");
	}

	public static void main(String[] args) {
		Sub obj_C = new Sub();
		obj_C.showB();
	}

}
