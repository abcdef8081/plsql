package com;

public class Vehicle {
	String name="Base Four Wheeler";
	String color="BaseBlue";
	String vno="BaseUP";
	
	Vehicle(){
		System.out.println("Default Base");
	}
	Vehicle(String msg){
		System.out.println("Base Param " + msg);
	}
	public void horn() {
		System.out.println("horn");
	}
	//static void brake() {
	void brake() {
		System.out.println("Base Brake");
	}
	public void gear() {
		System.out.println("Gear");
	}

}
