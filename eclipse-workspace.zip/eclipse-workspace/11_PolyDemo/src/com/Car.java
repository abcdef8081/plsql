package com;

public class Car extends Vehicle {
	
	String name="Child Volkswagon";
	Car(String msg){
		super("Technology");
		System.out.println("Child Param "+ msg);
	}
	//public static void brake()
	public void brake() {
		super.brake();
		System.out.println("Child Brake");
		//super.brake();
		System.out.println(super.name);
	}

	public static void main(String[] args) {
		Car c = new Car("Ameo");
		c.brake();
		//Vehicle.brake();
		
		System.out.println(c.name);
		
		//Vehicle v = new Vehicle();
		//v.brake();

	}

}
