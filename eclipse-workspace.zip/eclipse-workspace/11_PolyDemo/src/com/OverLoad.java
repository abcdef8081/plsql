package com;

public class OverLoad {

	public static void main(String[] args) {
		OverLoad ol = new OverLoad();
		System.out.println(ol.add(1,2));
		System.out.println(ol.add(1.0,2.5));
		ol.add("Over", "Load");
	}
	int add(int a, int b) {
		return a+b;
	}
	double add(double a, double b) {
		return a+b;
	}
	void add(String a, String b) {
		System.out.println(a+b);
	}
}
