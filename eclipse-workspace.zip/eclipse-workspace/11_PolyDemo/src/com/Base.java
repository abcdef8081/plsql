package com;

public class Base{
	String b = "B Class";
	
	Base(){
		System.out.println("Default B");
	}
	
	public void showB() {
		System.out.println("I am show of b");
	}

}
