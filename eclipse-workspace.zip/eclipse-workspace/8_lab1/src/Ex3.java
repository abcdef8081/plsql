
public class Ex3 {

	public static void main(String[] args) {
		int a = 533468;
		int p, n=a%10;
		int f = 0;
		while(a > 0) {
			p = a%10;
			a = a/10;
			n = a%10;
			if (p < n){
				System.out.print("No");
				f = 1;
				break;
			}
			
		}
		if(f == 0) {
		System.out.print("yes");
		}
	}

}
