
public class Ex4 {

	public static void main(String[] args) {
		double a =513;
		while(a > 2) {
			a = a/2;
		}
		if(a % 2 == 0) {
			System.out.println("Yes");
		} else {
			System.out.println("No");
		}
	}
}
