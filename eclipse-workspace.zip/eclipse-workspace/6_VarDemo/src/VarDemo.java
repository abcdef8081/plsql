
public class VarDemo {
	int b;
	static int c;

	public static void main(String[] args) {
		VarDemo obj = new VarDemo();
		System.out.println(obj.b);
		obj.test();
		System.out.println(obj.b);
		c=200;
		//int b = (10 > 8 ? 8:10);
		//System.out.print(b);
		System.out.println(c);
		obj.test();
		System.out.println(c);
	}
	
	public void test() {
		//local variable
		int a=50;
		b=60;
		c=100;
		System.out.println(c);
		//static int d=100;
	}

}

class Var2{
	public static void main(String[] args) {
	System.out.print(VarDemo.c);
}
}
