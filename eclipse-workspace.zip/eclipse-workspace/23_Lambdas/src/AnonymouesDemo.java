
public class AnonymouesDemo {

	public static void main(String[] args) {
		Sayable s = new Sayable() {
			@Override
			public void say() {
				System.out.println("Say Sayable");
			}
		};
		s.say();
		s.talk();
	}

}
