import java.util.ArrayList;

public class forEachDemo {

	public static void main(String[] args) {
		ArrayList<String> a = new ArrayList<>();
		a.add("abc");
		a.add("def");
		a.add("ghi");
		a.forEach(n -> System.out.println(n));
	}

}
