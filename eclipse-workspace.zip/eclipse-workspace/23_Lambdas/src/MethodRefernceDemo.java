
interface Inter{
	void show();
}
public class MethodRefernceDemo {
	
	public static void showstatic() {
		System.out.println("Static method");
	}

	public static void main(String[] args) {
		Inter i = MethodRefernceDemo::showstatic;
		i.show();

	}

}
