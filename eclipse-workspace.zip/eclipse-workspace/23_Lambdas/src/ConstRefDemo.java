
interface Inter3 {
	void show();
} 

public class ConstRefDemo {

	public ConstRefDemo() {
		System.out.println("Constructor Reference");
	}

	public static void main(String[] args) {
		Inter3 i = ConstRefDemo:: new;
		i.show();
	}

}