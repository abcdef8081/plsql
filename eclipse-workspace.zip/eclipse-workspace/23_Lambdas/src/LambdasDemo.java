
interface Adding {
	public int add(int a, int b);
}
public class LambdasDemo {

	public static void main(String[] args) {
		Sayable s = () ->  System.out.println("Say Sayable");
		s.say();
		s.talk();
		
		Adding ad = (a, b) -> (a+b);
		System.out.println(ad.add(5, 10));
		
		Adding ad1 = (int a, int b) -> (a+b);
		System.out.println(ad1.add(5, 10));
		
		Adding ad2 = (int a, int b) -> {return (a+b); };
		System.out.println(ad2.add(5, 10));
		
		int[] arr = {1,3,5,7,9};
		for(int n:arr) {
			System.out.println(n);
		}
		
	}
}
