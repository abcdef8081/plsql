
@FunctionalInterface
public interface Sayable {
	
	void say();
	
	default void talk() {
		System.out.println("Talk Sayable");
	}

}
