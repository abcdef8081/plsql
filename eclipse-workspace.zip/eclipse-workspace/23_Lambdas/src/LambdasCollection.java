import java.util.ArrayList;
import java.util.Collections;

class Product{
	
	int id;
	String name;
	float price;
	
	public Product(int id, String name, float price) {
		super();
		this.id = id;
		this.name = name;
		this.price = price;
	}
}

public class LambdasCollection {

	public static void main(String[] args) {
		ArrayList<Product> a = new ArrayList<>();
		a.add(new Product(101, "AC", 15000f));
		a.add(new Product(102, "TV", 10000f));
		a.add(new Product(103, "Laptop", 18000f));
		a.add(new Product(104, "Fridge", 12000f));
		
		Collections.sort(a, (p1, p2) -> { return p1.name.compareTo(p2.name); });
		for(Product p: a){
			System.out.println(p.id + " " + p.name + " " + p.price);
		}
	} 

}
