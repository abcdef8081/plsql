
interface Inter2 {
	void show();
}
public class InstanceDemo {
	
	public void showinstance() {
		System.out.println("Instance method");
	}

	public static void main(String[] args) {
		InstanceDemo obj = new InstanceDemo();
		Inter2 i = obj::showinstance;
		i.show();
		
		Inter2 i2 = new InstanceDemo()::showinstance;
		i2.show();
	}
}
