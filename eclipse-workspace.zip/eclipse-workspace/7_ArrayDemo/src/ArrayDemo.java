
public class ArrayDemo {

	public static void main(String[] args) {
		
		int[] arr;
		arr = new int[5];
		
		int[] arr1 = new int[5];
		int[] arr2 = {5, 2, 3, 6, 8};
		for(int i=0; i<arr2.length; i++) {
			System.out.println(arr2[i]);
		}
	}
}
