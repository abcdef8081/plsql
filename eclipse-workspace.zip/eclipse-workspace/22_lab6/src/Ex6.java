import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;

public class Ex6 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String s = sc.next();
		Date d1 = new Date();
		Calendar c;
		System.out.println(d1 + " ");
	}
}
