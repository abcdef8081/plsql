
public class Ex5 {

	public static void main(String[] args) {
		String s = "ANTZ";
		boolean b = true;
		for(int i=1; i<s.length(); i++) {
			if(s.charAt(i-1) > s.charAt(i)) {
				b = false;
			}
		}
		System.out.println(b);
	}

}
