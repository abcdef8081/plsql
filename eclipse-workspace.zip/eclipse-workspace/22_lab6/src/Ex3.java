import java.util.StringTokenizer;

public class Ex3 {

	public static void main(String[] args) {
		String s = "\nhi hi Hello world \nrahul gupta hi";
		int w=0, c=0, l=0;
		StringTokenizer st = new StringTokenizer(s);
		int sum = 0;
		while(st.hasMoreElements()) {
			st.nextElement();
			w++;
		}
		for(int i=0; i<s.length(); i++) {
			 if ((s.charAt(i) >= 'a' && s.charAt(i) <= 'z') || (s.charAt(i) >= 'A' && s.charAt(i) <= 'Z')){
				c++;
			} else if(s.charAt(i) == '\n') {
				l++;
			}
		}
		System.out.println(c + " " + w + " " + l);
	}

}
