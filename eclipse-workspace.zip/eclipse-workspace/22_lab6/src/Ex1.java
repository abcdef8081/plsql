import java.util.Scanner;
import java.util.StringTokenizer;

public class Ex1 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String s = sc.nextLine();
		System.out.println(s);
		StringTokenizer st = new StringTokenizer(s);
		int sum = 0;
		while(st.hasMoreElements()) {
			int a = Integer.parseInt(st.nextElement().toString());
			System.out.println(a);
			sum += a;
		}
		System.out.println(sum);                           
	}
}
      