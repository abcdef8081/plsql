
public interface MyInterface {
	
	void add();
	void sub();
	void mul();
	void div();

}
