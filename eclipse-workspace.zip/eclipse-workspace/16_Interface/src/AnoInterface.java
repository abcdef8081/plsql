
public interface AnoInterface {
	
	void mod();

}
