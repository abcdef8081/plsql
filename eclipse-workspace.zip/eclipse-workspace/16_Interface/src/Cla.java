
public class Cla implements MyInterface, AnoInterface {

	public static void main(String[] args) {
		Cla c = new Cla();
		c.add();
		c.sub();
		c.mul();
		c.div();
		c.mod();
	}

	@Override
	public void add() {
		System.out.println("add");		
	}

	@Override
	public void sub() {
		System.out.println("sub");
	}

	@Override
	public void mul() {
		System.out.println("mul");
	}

	@Override
	public void div() {
		System.out.println("div");
	}

	@Override
	public void mod() {
		System.out.println("mod");
	}

}
