
public class Student {
	
	private int id;
	private String name="mickey";
	private float fees;

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getFees() {
		return fees;
	}
	public void setFees(float fees) {
		this.fees = fees;
	}
	
	public static void main(String[] args) {	
		Student stu = new Student();
		stu.setName("rahul");
		System.out.println(stu.getName());
	}
}
