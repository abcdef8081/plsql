
public class ThisDemo {
	
	String name="rahul";
	
	ThisDemo(String name){
		System.out.println(name);
		System.out.println(this.name);
		this.name = name;
		System.out.println(name);
	}

	public static void main(String[] args) {
		new ThisDemo("mickey");
	}

}
