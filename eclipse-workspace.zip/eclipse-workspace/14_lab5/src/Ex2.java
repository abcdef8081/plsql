
public class Ex2 {

	public static void main(String[] args) {
		int n=4;
		Ex2 e2 = new Ex2();
		System.out.println(e2.fib(n));

	}
	public int fib(int n) {
		int a=0; 
		int b=1;
		int c=0;
		for(int i=0; i<n; i++) {
			c = a+b;
			a = b;
			b = c;
		}
		return c;
	}
	public int rfib(int n) {
		if(n == 0 || n == 1) {
			return 1;
		} else {
			return rfib(n-1) + rfib(n-2);
		}
	}
}
