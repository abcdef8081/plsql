import java.util.ArrayList;
import java.util.Collections;
import java.util.stream.Stream;

class Product{
	
	int id;
	String name;
	float price;
	
	public Product(int id, String name, float price) {
		super();
		this.id = id;
		this.name = name;
		this.price = price;
	}
}

public class StreamDemo {

	public static void main(String[] args) {
		ArrayList<Product> a = new ArrayList<>();
		a.add(new Product(101, "AC", 15000f));
		a.add(new Product(102, "TV", 10000f));
		a.add(new Product(103, "Laptop", 18000f));
		a.add(new Product(104, "Fridge", 12000f));
		
		Stream<Product> filtered = a.stream().filter(p->p.price>12000);
		
		filtered.forEach(product -> System.out.println(product.name + " " + product.price));
		
		long elements = Stream.of(1, 2, 3, 4, 5, 6, 7).filter(p->p.intValue() < 3).count();
		
		System.out.println(elements);
		
	} 

}
