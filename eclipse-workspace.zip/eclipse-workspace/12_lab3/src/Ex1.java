import java.util.Arrays;

public class Ex1 {

	public static void main(String[] args) {
		int[] arr = {5, 1, 2, 7, 6};
		Ex1 e1 = new Ex1();
		System.out.println(e1.second(arr));
		
	}
	public int second(int[] arr) {
		Arrays.sort(arr);
		return arr[1];
	}
 
}
