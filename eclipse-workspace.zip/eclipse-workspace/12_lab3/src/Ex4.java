import java.util.HashMap;

public class Ex4 {

	public static void main(String[] args) {
		Ex4 e4 = new Ex4();
		char[] arr = {'a', 'b', 'd', 'w', 'a', 'd'};
		HashMap<Character, Integer> h = new HashMap<>();
		e4.countCh(arr, h);
		
	}
	public void countCh(char[] arr, HashMap<Character, Integer> h) {
		h.put(arr[0], 1);
		for(int i=0; i<arr.length; i++) {
			if(h.containsKey(arr[i])) {
				int v = h.get(arr[i]);
				h.put(arr[i], v+1);
			}
			else {
				h.put(arr[i], 1);
			}
		}
		System.out.println(h.toString());
	}
}
