import java.util.Arrays;

public class Ex3 {

	public static void main(String[] args) {
		Ex3 e3 = new Ex3();
		int[] arr = {521, 414, 9464, 112, 245};
		for(int i=0; i<arr.length; i++) {
			int n = arr[i];
			int a = 0;
			while(n > 0) {
				int r = n%10;
				a = a*10 + r;
				n = n/10;
			}
			arr[i] = a;
			System.out.println(arr[i]);	
		}
		System.out.println(Arrays.toString(e3.getSorted(arr)));
	}
	public int[] getSorted(int[] arr) {
		Arrays.sort(arr);
		return arr;
	}

}
