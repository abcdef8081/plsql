import java.util.Arrays;

public class Ex2 {

	public static void main(String[] args) {
		Ex2 e2 = new Ex2();
		String[] arr = {"Hello", "world", "rahul", "gupta", "garg"};
		System.out.println(Arrays.toString(e2.func(arr)));

	}
	public String[] func(String[] arr) {
		Arrays.sort(arr);
		//System.out.println(Arrays.toString(arr));
		for(int i=0; i<arr.length/2; i++) {
			arr[i] = arr[i].toUpperCase();
		}
		for(int i=arr.length/2; i<arr.length; i++) {
			arr[i] = arr[i].toLowerCase();
		}
		if(arr.length %2 == 1) {
			arr[(arr.length/2)] = arr[(arr.length/2)].toUpperCase();
		}
		return arr;
	}

}
