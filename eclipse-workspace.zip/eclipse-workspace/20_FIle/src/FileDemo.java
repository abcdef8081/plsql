import java.io.*;

public class FileDemo {

	public static void main(String[] args) throws IOException {
		File f = new File("test.txt");
		FileReader fr = new FileReader(f);
		
		BufferedReader br = new BufferedReader(fr);
		//String msg = br.readLine();
		while(br.read() != -1) {
			System.out.println(br.readLine());
		}
		
		FileWriter fw = new FileWriter(new File("test1.txt"));
		br = new BufferedReader(fr);
		//fw.write(msg);
		while(br.readLine() != null) {
			fw.write(br.readLine());
		}
		fw.close();
	}
}
