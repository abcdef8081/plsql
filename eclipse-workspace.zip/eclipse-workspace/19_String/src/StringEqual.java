
public class StringEqual {

	public static void main(String[] args) {
		String s1 = "Java";
		String s2 = "Java";
		if(s1 == s2) {
			System.out.println("Equal ==");
		} else {
			System.out.println("Not equal ==");
		}
		if(s1.equals(s2)) {
			System.out.println("Equal equal");
		} else {
			System.out.println("Not equal equal");
		}
		
		String s3 = new String("Java");
		String s4  = "Java";
		if(s3 == s4) {
			System.out.println("Equal ==");
		} else {
			System.out.println("Not equal ==");
		}
		if(s3.equals(s4)) {
			System.out.println("Equal equal");
		} else {
			System.out.println("Not equal equal");
		}
		
		String s5 = new String("Java");
		String s6  = new String("Java");
		if(s5 == s6) {
			System.out.println("Equal ==");
		} else {
			System.out.println("Not equal ==");
		}
		if(s5.equals(s6)) {
			System.out.println("Equal equal");
		} else {
			System.out.println("Not equal equal");
		}
	}

}
