
public abstract class Emp {
	
	abstract public void doTask();
	
	abstract public void cardSwipe();
	
	public void getSalary() {
		System.out.println("Salary.");
	}
	public static void main(String[] args) {
		System.out.println("Abstract class main");
	}
	
	

}
