
public class itEmp extends Emp {
	
	public static void main(String[] args) {
		itEmp it = new itEmp();
		it.doTask();
		it.cardSwipe();
		it.getSalary();
	}

	@Override
	public void doTask() {
		System.out.println("Do assigned task.");
	}

	@Override
	public void cardSwipe() {
		System.out.println("Card Swipe.");
	}

}
