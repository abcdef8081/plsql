
public class UserExcepDemo {

	public static void main(String[] args) throws AgeException{
		int age = 10;
		if(age < 18) {
			throw new AgeException(age);
		}
		else {
			System.out.println("this is valid age to work.");
		}

	}

}
