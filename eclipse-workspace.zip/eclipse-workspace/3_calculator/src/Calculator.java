import java.util.Scanner;

public class Calculator {
	public static int a, b;
	public Calculator(int a, int b) {
		this.a = a;
		this.b = b;
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Additon ad = new Additon();
		int p, q;
		System.out.println("Enter two values: ");
		p = sc.nextInt();
		q = sc.nextInt();
		Calculator c = new Calculator(p, q);
		System.out.println("Add " + ad.add(a,b));
		System.out.println("Subtract " + c.subtract(a,b));
		System.out.println("Multiply " + c.multiply(a,b));
		System.out.println("Divide " + c.divide(a,b));
		System.out.println("Modulus " + c.mod(a,b));
		
		System.out.print("Enter a string: ");
		String s = sc.next();
		for (int i=0; i<4; i++) {
			System.out.print(s +  " ");
		}
		sc.close();
	}
	public int subtract(int a, int b) {
		return a-b;
	}
	public int multiply(int a, int b) {
		return a*b;
	}
	public double divide(int a, int b) {
		return (double) a/b;
	}
	public int mod(int a, int b) {
		return a%b;
	}
}
