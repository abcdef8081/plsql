
public class OprDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=5;
		a++;
		System.out.println(a);
		System.out.println(a++);
		System.out.println(++a);
		System.out.println(++a + a--);
		System.out.println(5 & 6);
		System.out.println(true && false);
		System.out.println(false & true);

	}

}
