
public class Pattern {
	public static void main(String[] args) {
		for(int i=0; i<8; i++) {
			for(int j=0; j<i && i <= 4; j++) {
				System.out.print("*");
			}
			for(int k=8-i; k>0 && i > 4; k--) {
				System.out.print("*");
			}
			System.out.println();
		}
	}
}
